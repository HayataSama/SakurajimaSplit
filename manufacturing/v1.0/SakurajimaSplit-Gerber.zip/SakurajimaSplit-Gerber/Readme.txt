File Description:

SakurajimaSplit-Edge_Cuts		PCB outline
SakurajimaSplit-NPTH			Non-Plated Through-Hole Drill File
SakurajimaSplit-PTH			Plated Through-Holes Drill File

SakurajimaSplit-F_Silkscreen		Top Silkscreen
SakurajimaSplit-F_Mask			Top Mask
SakurajimaSplit-F_Cu			Top Copper

SakurajimaSplit-B_Silkscreen		Bottom Silkscreen
SakurajimaSplit-B_Mask			Bottom Mask
SakurajimaSplit-B_Cu			Bottom Copper

SakurajimaSplit-job			Gerber Job File